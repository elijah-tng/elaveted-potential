package tripleo.elijah_fluffy.spi;

import javax.annotation.processing.Processor;
import javax.tools.Diagnostic;
import javax.tools.DiagnosticCollector;
import javax.tools.DiagnosticListener;
import javax.tools.FileObject;
import javax.tools.ForwardingFileObject;
import javax.tools.ForwardingJavaFileManager;
import javax.tools.ForwardingJavaFileObject;
import javax.tools.JavaFileManager;
import javax.tools.JavaFileObject;
import javax.tools.OptionChecker;
import javax.tools.SimpleJavaFileObject;
import javax.tools.StandardJavaFileManager;
import javax.tools.StandardLocation;
import javax.tools.Tool;
import java.io.Writer;
import java.nio.charset.Charset;
import java.security.AccessController;
import java.security.PrivilegedAction;
import java.util.Locale;
import java.util.Objects;
import java.util.ServiceConfigurationError;
import java.util.ServiceLoader;
import java.util.concurrent.Callable;

public class ElToolProvider {
	private static final String systemJavaCompilerModule = "jdk.compiler";
	private static final String systemJavaCompilerName   = "tripleo.elijah_fluffy.spi.javac_api.ElJavacTool";

	private ElToolProvider() {}

	/**
	 * Returns the Java programming language compiler provided
	 * with this platform.
	 * <p>The file manager returned by calling
	 * {@link ElijahCompiler#getStandardFileManager getStandardFileManager}
	 * on this compiler supports paths provided by any
	 * {@linkplain java.nio.file.FileSystem filesystem}.</p>
	 * @return the compiler provided with this platform or
	 * {@code null} if no compiler is provided
	 * @implNote This implementation returns the compiler provided
	 * by the {@code jdk.compiler} module if that module is available,
	 * and {@code null} otherwise.
	 */
	public static ElijahCompiler getSystemJavaCompiler() {
		return getSystemTool(ElijahCompiler.class,
		                     systemJavaCompilerModule, systemJavaCompilerName);
	}

	private static final String systemDocumentationToolModule = "jdk.javadoc";
	private static final String systemDocumentationToolName = "jdk.javadoc.internal.api.JavadocTool";

	/**
	 * Returns the Java programming language documentation tool provided
	 * with this platform.
	 * <p>The file manager returned by calling
	 * {@link DocumentationTool#getStandardFileManager getStandardFileManager}
	 * on this tool supports paths provided by any
	 * {@linkplain java.nio.file.FileSystem filesystem}.</p>
	 * @return the documentation tool provided with this platform or
	 * {@code null} if no documentation tool is provided
	 * @implNote This implementation returns the tool provided
	 * by the {@code jdk.javadoc} module if that module is available,
	 * and {@code null} otherwise.
	 */
	public static DocumentationTool getSystemDocumentationTool() {
		return getSystemTool(DocumentationTool.class,
		                     systemDocumentationToolModule, systemDocumentationToolName);
	}

	/**
	 * Returns a class loader that may be used to load system tools,
	 * or {@code null} if no such special loader is provided.
	 * @implSpec This implementation always returns {@code null}.
	 * @deprecated This method is subject to removal in a future version of
	 * Java SE.
	 * Use the {@link java.util.spi.ToolProvider system tool provider} or
	 * {@link java.util.ServiceLoader service loader} mechanisms to
	 * locate system tools as well as user-installed tools.
	 * @return a class loader, or {@code null}
	 */
	@Deprecated(since="9")
	public static ClassLoader getSystemToolClassLoader() {
		return null;
	}

	/**
	 * Get an instance of a system tool using the service loader.
	 * @implNote         By default, this returns the implementation in the specified module.
	 *                   For limited backward compatibility, if this code is run on an older version
	 *                   of the Java platform that does not support modules, this method will
	 *                   try and create an instance of the named class. Note that implies the
	 *                   class must be available on the system class path.
	 * @param <T>        the interface of the tool
	 * @param clazz      the interface of the tool
	 * @param moduleName the name of the module containing the desired implementation
	 * @param className  the class name of the desired implementation
	 * @return the specified implementation of the tool
	 */
	private static <T> T getSystemTool(Class<T> clazz, String moduleName, String className) {

		try {
			ServiceLoader<T> sl = ServiceLoader.load(clazz, ClassLoader.getSystemClassLoader());
			for (T tool : sl) {
				if (matches(tool, moduleName))
					return tool;
			}
		} catch (ServiceConfigurationError e) {
			throw new JCDiagnostic.Error_(e);
		}
		return null;
	}

	/**
	 * Determine if this is the desired tool instance.
	 * @param <T>               the interface of the tool
	 * @param tool              the instance of the tool
	 * @param moduleName        the name of the module containing the desired implementation
	 * @return true if and only if the tool matches the specified criteria
	 */
	@SuppressWarnings("removal")
	private static <T> boolean matches(T tool, String moduleName) {
		PrivilegedAction<Boolean> pa = () -> {
			Module toolModule = tool.getClass().getModule();
			String toolModuleName = toolModule.getName();
			return Objects.equals(toolModuleName, moduleName);
		};
		return AccessController.doPrivileged(pa);
	}


	/**
	 * Interface to invoke Java programming language documentation tools from
	 * programs.
	 *
	 * @since 1.8
	 */
	public interface DocumentationTool extends Tool, OptionChecker {
		/**
		 * Creates a future for a documentation task with the given
		 * components and arguments.  The task might not have
		 * completed as described in the DocumentationTask interface.
		 *
		 * <p>If a file manager is provided, it must be able to handle all
		 * locations defined in {@link javax.tools.DocumentationTool.Location},
		 * as well as
		 * {@link StandardLocation#SOURCE_PATH},
		 * {@link StandardLocation#CLASS_PATH}, and
		 * {@link StandardLocation#PLATFORM_CLASS_PATH}.
		 *
		 * @param out a Writer for additional output from the tool;
		 * use {@code System.err} if {@code null}
		 *
		 * @param fileManager a file manager; if {@code null} use the
		 * tool's standard file manager
		 *
		 * @param diagnosticListener a diagnostic listener; if {@code null}
		 * use the tool's default method for reporting diagnostics
		 *
		 * @param docletClass a class providing the necessary methods required
		 * of a doclet; a value of {@code null} means to use the standard doclet.
		 *
		 * @param options documentation tool options and doclet options,
		 * {@code null} means no options
		 *
		 * @param compilationUnits the compilation units to compile, {@code
		 * null} means no compilation units
		 *
		 * @return an object representing the compilation
		 *
		 * @throws RuntimeException if an unrecoverable error
		 * occurred in a user supplied component.  The
		 * {@linkplain Throwable#getCause() cause} will be the error in
		 * user code.
		 *
		 * @throws IllegalArgumentException if any of the given
		 * compilation units are of other kind than
		 * {@linkplain JavaFileObject.Kind#SOURCE source}
		 */
		javax.tools.DocumentationTool.DocumentationTask getTask(Writer out,
		                                                        JavaFileManager fileManager,
		                                                        DiagnosticListener<? super JavaFileObject> diagnosticListener,
		                                                        Class<?> docletClass,
		                                                        Iterable<String> options,
		                                                        Iterable<? extends JavaFileObject> compilationUnits);

		/**
		 * Returns a new instance of the standard file manager implementation
		 * for this tool.  The file manager will use the given diagnostic
		 * listener for producing any non-fatal diagnostics.  Fatal errors
		 * will be signaled with the appropriate exceptions.
		 *
		 * <p>The standard file manager will be automatically reopened if
		 * it is accessed after calls to {@code flush} or {@code close}.
		 * The standard file manager must be usable with other tools.
		 *
		 * @param diagnosticListener a diagnostic listener for non-fatal
		 * diagnostics; if {@code null} use the compiler's default method
		 * for reporting diagnostics
		 *
		 * @param locale the locale to apply when formatting diagnostics;
		 * {@code null} means the {@linkplain Locale#getDefault() default locale}.
		 *
		 * @param charset the character set used for decoding bytes; if
		 * {@code null} use the platform default
		 *
		 * @return the standard file manager
		 */
		StandardJavaFileManager getStandardFileManager(
				DiagnosticListener<? super JavaFileObject> diagnosticListener,
				Locale locale,
				Charset charset);

		/**
		 * Interface representing a future for a documentation task.  The
		 * task has not yet started.  To start the task, call
		 * the {@linkplain #call call} method.
		 *
		 * <p>Before calling the {@code call} method, additional aspects of the
		 * task can be configured, for example, by calling the
		 * {@linkplain #setLocale setLocale} method.
		 */
		interface DocumentationTask extends Callable<Boolean> {
			/**
			 * Adds root modules to be taken into account during module
			 * resolution.
			 * Invalid module names may cause either
			 * {@code IllegalArgumentException} to be thrown,
			 * or diagnostics to be reported when the task is started.
			 * @param moduleNames the names of the root modules
			 * @throws IllegalArgumentException may be thrown for some
			 *      invalid module names
			 * @throws IllegalStateException if the task has started
			 * @since 9
			 */
			void addModules(Iterable<String> moduleNames);

			/**
			 * Sets the locale to be applied when formatting diagnostics and
			 * other localized data.
			 *
			 * @param locale the locale to apply; {@code null} means apply no
			 * locale
			 * @throws IllegalStateException if the task has started
			 */
			void setLocale(Locale locale);

			/**
			 * Performs this documentation task.  The task may only
			 * be performed once.  Subsequent calls to this method throw
			 * {@code IllegalStateException}.
			 *
			 * @return true if and only all the files were processed without errors;
			 * false otherwise
			 *
			 * @throws RuntimeException if an unrecoverable error occurred
			 * in a user-supplied component.  The
			 * {@linkplain Throwable#getCause() cause} will be the error
			 * in user code.
			 *
			 * @throws IllegalStateException if called more than once
			 */
			@Override
			Boolean call();
		}

		/**
		 * Locations specific to {@link javax.tools.DocumentationTool}.
		 *
		 * @see StandardLocation
		 */
		enum Location implements JavaFileManager.Location {
			/**
			 * Location of new documentation files.
			 */
			DOCUMENTATION_OUTPUT,

			/**
			 * Location to search for doclets.
			 */
			DOCLET_PATH,

			/**
			 * Location to search for taglets.
			 */
			TAGLET_PATH,

			/**
			 * Location to search for snippets.
			 */
			SNIPPET_PATH;

			@Override
			public String getName() { return name(); }

			@Override
			public boolean isOutputLocation() {
				switch (this) {
				case DOCUMENTATION_OUTPUT:
					return true;
				default:
					return false;
				}
			}
		}

	}

	/**
	 * Interface to invoke Java programming language compilers from
	 * programs.
	 *
	 * <p>The compiler might generate diagnostics during compilation (for
	 * example, error messages).  If a diagnostic listener is provided,
	 * the diagnostics will be supplied to the listener.  If no listener
	 * is provided, the diagnostics will be formatted in an unspecified
	 * format and written to the default output, which is {@code
	 * System.err} unless otherwise specified.  Even if a diagnostic
	 * listener is supplied, some diagnostics might not fit in a {@code
	 * Diagnostic} and will be written to the default output.
	 *
	 * <p>A compiler tool has an associated standard file manager, which
	 * is the file manager that is native to the tool (or built-in).  The
	 * standard file manager can be obtained by calling {@linkplain
	 * #getStandardFileManager getStandardFileManager}.
	 *
	 * <p>A compiler tool must function with any file manager as long as
	 * any additional requirements as detailed in the methods below are
	 * met.  If no file manager is provided, the compiler tool will use a
	 * standard file manager such as the one returned by {@linkplain
	 * #getStandardFileManager getStandardFileManager}.
	 *
	 * <p>An instance implementing this interface must conform to
	 * <cite>The Java Language Specification</cite>
	 * and generate class files conforming to
	 * <cite>The Java Virtual Machine Specification</cite>.
	 * The versions of these
	 * specifications are defined in the {@linkplain Tool} interface.
	 *
	 * Additionally, an instance of this interface supporting {@link
	 * javax.lang.model.SourceVersion#RELEASE_6 SourceVersion.RELEASE_6}
	 * or higher must also support {@linkplain javax.annotation.processing
	 * annotation processing}.
	 *
	 * <p>The compiler relies on two services: {@linkplain
	 * DiagnosticListener diagnostic listener} and {@linkplain
	 * JavaFileManager file manager}.  Although most classes and
	 * interfaces in this package defines an API for compilers (and
	 * tools in general) the interfaces {@linkplain DiagnosticListener},
	 * {@linkplain JavaFileManager}, {@linkplain FileObject}, and
	 * {@linkplain JavaFileObject} are not intended to be used in
	 * applications.  Instead these interfaces are intended to be
	 * implemented and used to provide customized services for a
	 * compiler and thus defines an SPI for compilers.
	 *
	 * <p>There are a number of classes and interfaces in this package
	 * which are designed to ease the implementation of the SPI to
	 * customize the behavior of a compiler:
	 *
	 * <dl>
	 *   <dt>{@link StandardJavaFileManager}</dt>
	 *   <dd>
	 *
	 *     Every compiler which implements this interface provides a
	 *     standard file manager for operating on regular {@linkplain
	 *     java.io.File files}.  The StandardJavaFileManager interface
	 *     defines additional methods for creating file objects from
	 *     regular files.
	 *
	 *     <p>The standard file manager serves two purposes:
	 *
	 *     <ul>
	 *       <li>basic building block for customizing how a compiler reads
	 *       and writes files</li>
	 *       <li>sharing between multiple compilation tasks</li>
	 *     </ul>
	 *
	 *     <p>Reusing a file manager can potentially reduce overhead of
	 *     scanning the file system and reading jar files.  Although there
	 *     might be no reduction in overhead, a standard file manager must
	 *     work with multiple sequential compilations making the following
	 *     example a recommended coding pattern:
	 *
	 *     {@snippet id = "use-sjfm" lang = java:
	 *       File[] files1 = null ; // input for first compilation task     // @replace substring=null replacement="..."
	 *       File[] files2 = null ; // input for second compilation task    // @replace substring=null replacement="..."
	 *
	 *       ElijahCompiler compiler = ElToolProvider.getSystemJavaCompiler();
	 *       StandardJavaFileManager fileManager = compiler.getStandardFileManager(null, null, null);
	 *
	 *       Iterable<? extends JavaFileObject> compilationUnits1 =
	 *           fileManager.getJavaFileObjectsFromFiles(Arrays.asList(files1));  // @link substring=Arrays.asList target="java.util.Arrays#asList"
	 *       compiler.getTask(null, fileManager, null, null, null, compilationUnits1).call();
	 *
	 *       Iterable<? extends JavaFileObject> compilationUnits2 =
	 *           fileManager.getJavaFileObjects(files2); // use alternative method
	 *       // reuse the same file manager to allow caching of jar files
	 *       compiler.getTask(null, fileManager, null, null, null, compilationUnits2).call();
	 *
	 *       fileManager.close();
	 *}
	 *
	 *   </dd>
	 *
	 *   <dt>{@link DiagnosticCollector}</dt>
	 *   <dd>
	 *     Used to collect diagnostics in a list, for example:
	 *     {@snippet id = "use-diag-collector" lang = java:
	 *       Iterable<? extends JavaFileObject> compilationUnits = null;        // @replace substring=null replacement="..."
	 *       ElijahCompiler compiler = ElToolProvider.getSystemJavaCompiler();
	 *       DiagnosticCollector<JavaFileObject> diagnostics = new DiagnosticCollector<JavaFileObject>();
	 *       StandardJavaFileManager fileManager = compiler.getStandardFileManager(diagnostics, null, null);
	 *       compiler.getTask(null, fileManager, diagnostics, null, null, compilationUnits).call();
	 *
	 *       for (Diagnostic<? extends JavaFileObject> diagnostic : diagnostics.getDiagnostics()) {
	 *           System.out.format("JCDiagnostic.Error_ on line %d in %s%n",
	 *                             diagnostic.getLineNumber(),
	 *                             diagnostic.getSource().toUri());
	 *       }
	 *
	 *       fileManager.close();
	 *}
	 *   </dd>
	 *
	 *   <dt>
	 *     {@link ForwardingJavaFileManager}, {@link ForwardingFileObject}, and
	 *     {@link ForwardingJavaFileObject}
	 *   </dt>
	 *   <dd>
	 *
	 *     Subclassing is not available for overriding the behavior of a
	 *     standard file manager as it is created by calling a method on a
	 *     compiler, not by invoking a constructor.  Instead forwarding
	 *     (or delegation) should be used.  These classes makes it easy to
	 *     forward most calls to a given file manager or file object while
	 *     allowing customizing behavior.  For example, consider how to
	 *     log all calls to {@linkplain JavaFileManager#flush}:
	 *
	 *     {@snippet id = "forward-fm" lang = java:
	 *       final  Logger logger = null;                                       // @replace substring=null replacement="..."
	 *       Iterable<? extends JavaFileObject> compilationUnits = null;        // @replace substring=null replacement="..."
	 *       ElijahCompiler compiler = ElToolProvider.getSystemJavaCompiler();
	 *       StandardJavaFileManager stdFileManager = compiler.getStandardFileManager(null, null, null);
	 *       JavaFileManager fileManager = new ForwardingJavaFileManager(stdFileManager) {
	 *           @Override
	 *           public void flush() throws IOException {
	 *               logger.entering(StandardJavaFileManager.class.getName(), "flush");
	 *               super.flush();
	 *               logger.exiting(StandardJavaFileManager.class.getName(), "flush");
	 *           }
	 *       };
	 *       compiler.getTask(null, fileManager, null, null, null, compilationUnits).call();
	 *}
	 *   </dd>
	 *
	 *   <dt>{@link SimpleJavaFileObject}</dt>
	 *   <dd>
	 *
	 *     This class provides a basic file object implementation which
	 *     can be used as building block for creating file objects.  For
	 *     example, here is how to define a file object which represent
	 *     source code stored in a string:
	 *
	 *     {@snippet id=fileObject class=JavaSourceFromString }
	 *   </dd>
	 * </dl>
	 *
	 * @see DiagnosticListener
	 * @see Diagnostic
	 * @see JavaFileManager
	 * @since 1.6
	 */
	public interface ElijahCompiler extends Tool, OptionChecker {

		/**
		 * Creates a future for a compilation task with the given
		 * components and arguments.  The compilation might not have
		 * completed as described in the CompilationTask interface.
		 *
		 * <p>If a file manager is provided, it must be able to handle all
		 * locations defined in {@link StandardLocation}.
		 *
		 * <p>Note that annotation processing can process both the
		 * compilation units of source code to be compiled, passed with
		 * the {@code compilationUnits} parameter, as well as class
		 * files, whose names are passed with the {@code classes}
		 * parameter.
		 *
		 * @param out a Writer for additional output from the compiler;
		 * use {@code System.err} if {@code null}
		 * @param fileManager a file manager; if {@code null} use the
		 * compiler's standard file manager
		 * @param diagnosticListener a diagnostic listener; if {@code
		 * null} use the compiler's default method for reporting
		 * diagnostics
		 * @param options compiler options, {@code null} means no options
		 * @param classes names of classes to be processed by annotation
		 * processing, {@code null} means no class names
		 * @param compilationUnits the compilation units to compile, {@code
		 * null} means no compilation units
		 * @return an object representing the compilation
		 * @throws RuntimeException if an unrecoverable error
		 * occurred in a user supplied component.  The
		 * {@linkplain Throwable#getCause() cause} will be the error in
		 * user code.
		 * @throws IllegalArgumentException if any of the options are invalid,
		 * or if any of the given compilation units are of other kind than
		 * {@linkplain JavaFileObject.Kind#SOURCE source}
		 */
		javax.tools.JavaCompiler.CompilationTask getTask(Writer out,
		                                                 JavaFileManager fileManager,
		                                                 DiagnosticListener<? super JavaFileObject> diagnosticListener,
		                                                 Iterable<String> options,
		                                                 Iterable<String> classes,
		                                                 Iterable<? extends JavaFileObject> compilationUnits);

		/**
		 * Returns a new instance of the standard file manager implementation
		 * for this tool.  The file manager will use the given diagnostic
		 * listener for producing any non-fatal diagnostics.  Fatal errors
		 * will be signaled with the appropriate exceptions.
		 *
		 * <p>The standard file manager will be automatically reopened if
		 * it is accessed after calls to {@code flush} or {@code close}.
		 * The standard file manager must be usable with other tools.
		 *
		 * @param diagnosticListener a diagnostic listener for non-fatal
		 * diagnostics; if {@code null} use the compiler's default method
		 * for reporting diagnostics
		 * @param locale the locale to apply when formatting diagnostics;
		 * {@code null} means the {@linkplain Locale#getDefault() default locale}.
		 * @param charset the character set used for decoding bytes; if
		 * {@code null} use the platform default
		 * @return the standard file manager
		 */
		StandardJavaFileManager getStandardFileManager(
				DiagnosticListener<? super JavaFileObject> diagnosticListener,
				Locale locale,
				Charset charset);

		/**
		 * Interface representing a future for a compilation task.  The
		 * compilation task has not yet started.  To start the task, call
		 * the {@linkplain #call call} method.
		 *
		 * <p>Before calling the {@code call} method, additional aspects of the
		 * task can be configured, for example, by calling the
		 * {@linkplain #setProcessors setProcessors} method.
		 */
		interface CompilationTask extends Callable<Boolean> {
			/**
			 * Adds root modules to be taken into account during module
			 * resolution.
			 * Invalid module names may cause either
			 * {@code IllegalArgumentException} to be thrown,
			 * or diagnostics to be reported when the task is started.
			 * @param moduleNames the names of the root modules
			 * @throws IllegalArgumentException may be thrown for some
			 *      invalid module names
			 * @throws IllegalStateException if the task has started
			 * @since 9
			 */
			void addModules(Iterable<String> moduleNames);

			/**
			 * Sets processors (for annotation processing).  This will
			 * bypass the normal discovery mechanism.
			 *
			 * @param processors processors (for annotation processing)
			 * @throws IllegalStateException if the task has started
			 */
			void setProcessors(Iterable<? extends Processor> processors);

			/**
			 * Sets the locale to be applied when formatting diagnostics and
			 * other localized data.
			 *
			 * @param locale the locale to apply; {@code null} means apply no
			 * locale
			 * @throws IllegalStateException if the task has started
			 */
			void setLocale(Locale locale);

			/**
			 * Performs this compilation task.  The compilation may only
			 * be performed once.  Subsequent calls to this method throw
			 * {@code IllegalStateException}.
			 *
			 * @return true if and only all the files compiled without errors;
			 * false otherwise
			 *
			 * @throws RuntimeException if an unrecoverable error occurred
			 * in a user-supplied component.  The
			 * {@linkplain Throwable#getCause() cause} will be the error
			 * in user code.
			 * @throws IllegalStateException if called more than once
			 */
			@Override
			Boolean call();
		}
	}
}
