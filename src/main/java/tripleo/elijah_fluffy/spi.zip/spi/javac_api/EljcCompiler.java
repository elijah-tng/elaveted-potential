package tripleo.elijah_fluffy.spi.javac_api;

import javax.lang.model.SourceVersion;
import javax.tools.*;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.Writer;
import java.nio.charset.Charset;
import java.util.Locale;
import java.util.Set;

public interface EljcCompiler extends JavaCompiler, ElijahCompiler {
//	public default JavaCompiler getEljcCompiler() {
//		return new AbstractElijahCompiler(){};
//	}

	public abstract class AbstractElijahCompiler implements JavaCompiler, ElijahCompiler {
		@Override
		public CompilationTask getTask(final Writer out, final JavaFileManager fileManager, final DiagnosticListener<? super JavaFileObject> diagnosticListener, final Iterable<String> options, final Iterable<String> classes, final Iterable<? extends JavaFileObject> compilationUnits) {
			return null;
		}

		@Override
		public StandardJavaFileManager getStandardFileManager(final DiagnosticListener<? super JavaFileObject> diagnosticListener, final Locale locale, final Charset charset) {
			return null;
		}

		@Override
		public int isSupportedOption(final String option) {
			return 0;
		}

		@Override
		public int run(final InputStream in, final OutputStream out, final OutputStream err, final String... arguments) {
			return 0;
		}

		@Override
		public Set<SourceVersion> getSourceVersions() {
			return Set.of();
		}
	}
}
