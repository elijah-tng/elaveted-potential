package tripleo.elijah_fluffy.spi.javac_api;

import com.sun.source.util.JavacTask;
import tripleo.elijah_fluffy.spi.javac.api.ClientCodeWrapper;
import tripleo.elijah_fluffy.spi.javac.api.JavacTaskImpl;
import tripleo.elijah_fluffy.spi.javac.api.JavacTool;
import tripleo.elijah_fluffy.spi.javac.file.BaseFileManager;
import tripleo.elijah_fluffy.spi.javac.file.CacheFSInfo;
import tripleo.elijah_fluffy.spi.javac.file.JavacFileManager;
import tripleo.elijah_fluffy.spi.javac.jvm.Target;
import tripleo.elijah_fluffy.spi.javac.main.Arguments;
import tripleo.elijah_fluffy.spi.javac.main.Option;
import tripleo.elijah_fluffy.spi.javac.util.*;
import tripleo.elijah_fluffy.spi.javac.util.List;

import javax.lang.model.SourceVersion;
import javax.tools.DiagnosticListener;
import javax.tools.JavaFileManager;
import javax.tools.JavaFileObject;
import java.io.*;
import java.nio.charset.Charset;
import java.util.*;

public class ElJavacTool implements EljcCompiler {
	/**
	 * Constructor used by service provider mechanism.  The recommended way to
	 * obtain an instance of this class is by using {@link #create} or the
	 * service provider mechanism.
	 * @see javax.tools.JavaCompiler
	 * @see javax.tools.ToolProvider
	 * @see #create
	 */
	@Deprecated
	public ElJavacTool() {
	}

	// @Override // can't add @Override until bootstrap JDK provides Tool.name()
	@DefinedBy(DefinedBy.Api.COMPILER)
	public String name() {
		return "javac";
	}

//	/**
//	 * Static factory method for creating new instances of this tool.
//	 * @return new instance of this tool
//	 */
//	public static JavacTool create() {
//		return new JavacTool();
//	}

	@Override
	@DefinedBy(DefinedBy.Api.COMPILER)
	public JavacFileManager getStandardFileManager(
			DiagnosticListener<? super JavaFileObject> diagnosticListener,
			Locale locale,
			Charset charset) {
		Context context = new Context();
		context.put(Locale.class, locale);
		if (diagnosticListener != null)
			context.put(DiagnosticListener.class, diagnosticListener);
		PrintWriter pw = (charset == null)
				? new PrintWriter(System.err, true)
				: new PrintWriter(new OutputStreamWriter(System.err, charset), true);
		context.put(Log.errKey, pw);
		CacheFSInfo.preRegister(context);
		return new JavacFileManager(context, true, charset);
	}

	@Override
	@DefinedBy(DefinedBy.Api.COMPILER)
	public JavacTask getTask(Writer out,
	                         JavaFileManager fileManager,
	                         DiagnosticListener<? super JavaFileObject> diagnosticListener,
	                         Iterable<String> options,
	                         Iterable<String> classes,
	                         Iterable<? extends JavaFileObject> compilationUnits) {
		Context context = new Context();
		return getTask(out, fileManager, diagnosticListener,
		               options, classes, compilationUnits,
		               context
		);
	}

	/* Internal version of getTask, allowing context to be provided. */
	public JavacTask getTask(Writer out,
	                         JavaFileManager fileManager,
	                         DiagnosticListener<? super JavaFileObject> diagnosticListener,
	                         Iterable<String> options,
	                         Iterable<String> classes,
	                         Iterable<? extends JavaFileObject> compilationUnits,
	                         Context context) {
		try {
			ClientCodeWrapper ccw = ClientCodeWrapper.instance(context);

			if (options != null) {
				for (String option : options)
					Objects.requireNonNull(option);
			}

			if (classes != null) {
				for (String cls : classes) {
					int sep = cls.indexOf('/'); // implicit null check
					if (sep > 0) {
						String mod = cls.substring(0, sep);
						if (!SourceVersion.isName(mod))
							throw new IllegalArgumentException("Not a valid module name: " + mod);
						cls = cls.substring(sep + 1);
					}
					if (!SourceVersion.isName(cls))
						throw new IllegalArgumentException("Not a valid class name: " + cls);
				}
			}

			if (compilationUnits != null) {
				compilationUnits = ccw.wrapJavaFileObjects(compilationUnits); // implicit null check
				for (JavaFileObject cu : compilationUnits) {
					if (cu.getKind() != JavaFileObject.Kind.SOURCE) {
						String kindMsg = "Compilation unit is not of SOURCE kind: "
								+ "\"" + cu.getName() + "\"";
						throw new IllegalArgumentException(kindMsg);
					}
				}
			}

			if (diagnosticListener != null)
				context.put(DiagnosticListener.class, ccw.wrap(diagnosticListener));

			// If out is null and the value is set in the context, we need to do nothing.
			if (out == null && context.get(Log.errKey) == null)
				// Situation: out is null and the value is not set in the context.
				context.put(Log.errKey, new PrintWriter(System.err, true));
			else if (out instanceof PrintWriter pw)
				// Situation: out is not null and out is a PrintWriter.
				context.put(Log.errKey, pw);
			else if (out != null)
				// Situation: out is not null and out is not a PrintWriter.
				context.put(Log.errKey, new PrintWriter(out, true));

			if (fileManager == null) {
				fileManager = getStandardFileManager(diagnosticListener, null, null);
				if (fileManager instanceof BaseFileManager baseFileManager) {
					baseFileManager.autoClose = true;
				}
			}
			fileManager = ccw.wrap(fileManager);

			context.put(JavaFileManager.class, fileManager);

			Arguments args = Arguments.instance(context);
			args.init("javac", options, classes, compilationUnits);

			// init multi-release jar handling
			if (fileManager.isSupportedOption(Option.MULTIRELEASE.primaryName) == 1) {
				Target       target = Target.instance(context);
				List<String> list   = List.of(target.multiReleaseValue());
				fileManager.handleOption(Option.MULTIRELEASE.primaryName, list.iterator());
			}

			return new JavacTaskImpl(context);
		} catch (PropagatedException ex) {
			throw ex.getCause();
		} catch (ClientCodeException ex) {
			throw new RuntimeException(ex.getCause());
		}
	}

	@Override
	@DefinedBy(DefinedBy.Api.COMPILER)
	public int run(InputStream in, OutputStream out, OutputStream err, String... arguments) {
		if (err == null)
			err = System.err;
		for (String argument : arguments)
			Objects.requireNonNull(argument);
		return tripleo.elijah_fluffy.spi.javac.Main.compile(arguments, new PrintWriter(err, true));
	}

	@Override
	@DefinedBy(DefinedBy.Api.COMPILER)
	public Set<SourceVersion> getSourceVersions() {
		return Collections.unmodifiableSet(EnumSet.range(
				SourceVersion.RELEASE_3,
				SourceVersion.latest()
		));
	}

	@Override
	@DefinedBy(DefinedBy.Api.COMPILER)
	public int isSupportedOption(String option) {
		Set<Option> recognizedOptions = Option.getJavacToolOptions();
		for (Option o : recognizedOptions) {
			if (o.matches(option)) {
				return o.hasSeparateArg() ? 1 : 0;
			}
		}
		return -1;
	}
}
