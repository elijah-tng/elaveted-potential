package tripleo.elijah_fluffy.spi.javac.resources;

import java.nio.file.Path;

public class LauncherProperties {
    public static class Errors {
        /**
         * launcher.err.cant.access.main.method=\
         *    can''t access main method in class: {0}
         */
        public static JCDiagnostic.Error_ CantAccessMainMethod(String arg0) {
            return new JCDiagnostic.Error_("launcher", "cant.access.main.method", arg0);
        }
        
        /**
         * launcher.err.cant.find.class=\
         *    can''t find class: {0}
         */
        public static JCDiagnostic.Error_ CantFindClass(String arg0) {
            return new JCDiagnostic.Error_("launcher", "cant.find.class", arg0);
        }
        
        /**
         * launcher.err.cant.find.main.method=\
         *    can''t find main(String[]) method in class: {0}
         */
        public static JCDiagnostic.Error_ CantFindMainMethod(String arg0) {
            return new JCDiagnostic.Error_("launcher", "cant.find.main.method", arg0);
        }
        
        /**
         * launcher.err.cant.read.file=\
         *    error reading source file {0}: {1}
         */
        public static JCDiagnostic.Error_ CantReadFile(Path arg0, Object arg1) {
            return new JCDiagnostic.Error_("launcher", "cant.read.file", arg0, arg1);
        }
        
        /**
         * launcher.err.compilation.failed=\
         *    compilation failed
         */
        public static final JCDiagnostic.Error_ CompilationFailed = new JCDiagnostic.Error_("launcher", "compilation.failed");
        
        /**
         * launcher.err.enable.preview.requires.source=\
         *    --enable-preview must be used with --source
         */
        public static final JCDiagnostic.Error_ EnablePreviewRequiresSource = new JCDiagnostic.Error_("launcher", "enable.preview.requires.source");
        
        /**
         * launcher.err.file.not.found=\
         *    source file not found: {0}
         */
        public static JCDiagnostic.Error_ FileNotFound(Path arg0) {
            return new JCDiagnostic.Error_("launcher", "file.not.found", arg0);
        }
        
        /**
         * launcher.err.invalid.filename=\
         *    invalid path for source file: {0}
         */
        public static JCDiagnostic.Error_ InvalidFilename(String arg0) {
            return new JCDiagnostic.Error_("launcher", "invalid.filename", arg0);
        }
        
        /**
         * launcher.err.invalid.value.for.source=\
         *    invalid value for --source option: {0}
         */
        public static JCDiagnostic.Error_ InvalidValueForSource(String arg0) {
            return new JCDiagnostic.Error_("launcher", "invalid.value.for.source", arg0);
        }
        
        /**
         * launcher.err.main.not.public.static=\
         *    ''main'' method is not declared ''public static''
         */
        public static final JCDiagnostic.Error_ MainNotPublicStatic = new JCDiagnostic.Error_("launcher", "main.not.public.static");
        
        /**
         * launcher.err.main.not.void=\
         *    ''main'' method is not declared with a return type of ''void''
         */
        public static final JCDiagnostic.Error_ MainNotVoid = new JCDiagnostic.Error_("launcher", "main.not.void");
        
        /**
         * launcher.err.no.args=\
         *    no path for source file
         */
        public static final JCDiagnostic.Error_ NoArgs = new JCDiagnostic.Error_("launcher", "no.args");
        
        /**
         * launcher.err.no.class=\
         *    no class declared in source file
         */
        public static final JCDiagnostic.Error_ NoClass = new JCDiagnostic.Error_("launcher", "no.class");
        
        /**
         * launcher.err.no.value.for.option=\
         *    no value given for option: {0}
         */
        public static JCDiagnostic.Error_ NoValueForOption(String arg0) {
            return new JCDiagnostic.Error_("launcher", "no.value.for.option", arg0);
        }
    }
}
