package tripleo.elijah_fluffy.spi.javac.resources;

public final class version extends java.util.ListResourceBundle {
    protected final Object[][] getContents() {
        return new Object[][] {
            { "full", "17.0.11+9" },
            { "jdk", "17.0.11" },
            { "release", "17.0.11" },
        };
    }
}
